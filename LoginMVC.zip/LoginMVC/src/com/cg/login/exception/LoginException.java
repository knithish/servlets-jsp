package com.cg.login.exception;

public class LoginException extends Exception {

	public LoginException() {
		// TODO Auto-generated constructor stub
	}

	public LoginException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}

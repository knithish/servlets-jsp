package com.igate.auction.exception;

public class MyException extends Exception {
	public MyException(String msg) {
		super(msg);
	}
}

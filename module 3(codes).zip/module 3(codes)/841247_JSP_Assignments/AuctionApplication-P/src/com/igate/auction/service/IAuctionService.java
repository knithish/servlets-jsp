package com.igate.auction.service;

import java.util.Map;
import java.util.Set;

import com.igate.auction.bean.ItemsBean;
import com.igate.auction.exception.MyException;

public interface IAuctionService {
	boolean getLoginDetails(String username,String password) throws MyException;
	Map<Integer, ItemsBean> getItemsDetails() throws MyException;
	Map<Integer, ItemsBean> updateStatus(int itemId) throws MyException;
	void updateDB(int itemId) throws MyException;
}

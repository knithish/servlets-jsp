package com.igate.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.auction.bean.ItemsBean;
import com.igate.auction.exception.MyException;
import com.igate.auction.service.AuctionServiceImpl;
import com.igate.auction.service.IAuctionService;

/**
 * Servlet implementation class SuccessController
 */
@WebServlet("/SuccessController")
public class SuccessController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Map<Integer, ItemsBean> map=new HashMap<Integer, ItemsBean>();
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IAuctionService service=new AuctionServiceImpl();
		HttpSession session=request.getSession();
		PrintWriter pw=response.getWriter();
		//int id1=(int) request.getAttribute("id");
		pw.println("Welcome......."+request.getParameter("uname"));
		try {
			Map<Integer, ItemsBean> map=service.getItemsDetails();
			Iterator<ItemsBean> itr=map.values().iterator();
			
			pw.println("<html><body><form name='form1'>");
			pw.println("<table border=1 align='center'>");
			pw.println("<tr><th>Item Id</th><th>Item Name</th><th>Item Price</th><th>Item Status</th>");
			pw.println("</tr>");
			
			while(itr.hasNext()) {
				ItemsBean bean=itr.next();
				int id=bean.getItemId();
				String itemName=bean.getItemName();
				double price=bean.getItemPrice();
				String status=bean.getItemStatus();
				System.out.println(id);
				pw.println("<tr>");
		
				pw.println("<td>"+id+"</td>");
				pw.println("<td>"+itemName+"</td>");
				pw.println("<td>"+price+"</td>");
				
				pw.println("<td><a href='BiddingCart?id1="+id+"'>"+status+"</a></td>");
				//session.setAttribute("id", id);
				pw.println("</tr>");
			}
			
			pw.println("</table>");
			pw.println("</form></body><html>");
			
		} catch (MyException e) {
			
		}
		
	}

}

package com.igate.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.auction.bean.ItemsBean;
import com.igate.auction.exception.MyException;
import com.igate.auction.service.AuctionServiceImpl;
import com.igate.auction.service.IAuctionService;

/**
 * Servlet implementation class LoginController
 */
@WebServlet("/LoginController")
public class AuctionController extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	
	static Map<Integer, ItemsBean> map=new HashMap<Integer, ItemsBean>();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		IAuctionService service=new AuctionServiceImpl();
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession();
		String userName=request.getParameter("uname");
		String pwd=request.getParameter("pwd");
		
		try {
			boolean login=service.getLoginDetails(userName, pwd);
			
			String itemId=request.getParameter("id");
			String removeId=request.getParameter("remove");
			String option=request.getParameter("name");
				
			if(option!=null) {
				pw.println("Welcome......."+session.getAttribute("uname"));
				//Map<Integer, ItemsBean> map=null;
				double total=0;
				//map=service.updateStatus(itemId1);
				Map<Integer, ItemsBean> map=(Map<Integer, ItemsBean>) session.getAttribute("mapItr");
				Iterator<ItemsBean> itr=map.values().iterator();
				pw.println("<html><body><form>");
				pw.println("<table border=1>");
				pw.println("<tr><th>Item Id</th><th>Item Name</th><th>Item Price</th>");
				pw.println("</tr>");
				while(itr.hasNext()) {
					ItemsBean bean=itr.next();
					int id=bean.getItemId();
					service.updateDB(id);
					String itemName=bean.getItemName();
					double price=bean.getItemPrice();
					total+=price;
			
					pw.println("<tr><td>"+id+"</td>");
					pw.println("<td>"+itemName+"</td>");
					pw.println("<td>"+price+"</td></tr>");
					//System.out.println(update+" rows updated");
				}
				
				pw.println("</table>");
				pw.println("Final price-----"+total);
				pw.println("Thank you for bidding with us");
				
				
				session.invalidate();
				
				pw.println("<a href='index.html'>Logout</a>");
				pw.println("</form></body><html>");
			} else
				
			if(removeId!=null) {
				int itemId1=Integer.parseInt(removeId);
				pw.println("Welcome......."+session.getAttribute("uname"));
				Map<Integer, ItemsBean> map=null;
				//map=service.updateStatus(itemId1);
				map=(Map<Integer, ItemsBean>) session.getAttribute("mapItr");
				map.remove(itemId1);
				session.setAttribute("mapItr", map);
				Iterator<ItemsBean> itr=map.values().iterator();
				pw.println("<html><body><form action='LoginController?name=ok' method='post'>");
				pw.println("<table border='1' align='center' id='myTable'>");
				pw.println("<tr><th>Item Id</th><th>Item Name</th><th>Item Price</th><th>Item Status</th><th>Remove</th>");
				pw.println("</tr>");
				
				while(itr.hasNext()) {
					ItemsBean bean=itr.next();
					int id=bean.getItemId();
					String itemName=bean.getItemName();
					double price=bean.getItemPrice();
					String status=bean.getItemStatus();
					pw.println("<tr>");
			
					pw.println("<td>"+id+"</td>");
					pw.println("<td>"+itemName+"</td>");
					pw.println("<td>"+price+"</td>");
					pw.println("<td>"+status+"</td>");
					pw.println("<td><a href='LoginController?remove="+id+"'>Remove from bidding cart</a></td>");
					pw.println("</tr>");
				}
				pw.println("</table>");
				pw.println("<input type='submit' name='confirm' value='Confirm Bidding'>");
				pw.println("<a href='LoginController?login=true'>Go Back to Original Bidding Items List</a>");
				pw.println("</form></body><html>");
			} else
				
			if(itemId!=null) {
				int itemId1=Integer.parseInt(itemId);
				String name=(String) session.getAttribute("uname");
				String pwd1=(String) session.getAttribute("pwd");
				pw.println("Welcome......."+name);
				Map<Integer, ItemsBean> map=null;
				map=service.updateStatus(itemId1);
				session.setAttribute("mapItr", map);
				Iterator<ItemsBean> itr=map.values().iterator();
				pw.println("<html><body><form action='LoginController?name=ok' method='post'>");
				pw.println("<table border=1 align='center' id='myTable'>");
				pw.println("<tr><th>Item Id</th><th>Item Name</th><th>Item Price</th><th>Item Status</th><th>Remove</th>");
				pw.println("</tr>");
				
				while(itr.hasNext()) {
					ItemsBean bean=itr.next();
					int id=bean.getItemId();
					String itemName=bean.getItemName();
					double price=bean.getItemPrice();
					String status=bean.getItemStatus();
					pw.println("<tr>");
			
					pw.println("<td>"+id+"</td>");
					pw.println("<td>"+itemName+"</td>");
					pw.println("<td>"+price+"</td>");
					pw.println("<td>"+status+"</td>");
					pw.println("<td><a href='LoginController?remove="+id+"'>Remove from bidding cart</a></td>");
					pw.println("</tr>");
				}
				pw.println("</table>");
				pw.println("<input type='submit' name='confirm' value='Confirm Bidding'>");
				pw.println("<a href='LoginController?uname="+name+"&pwd="+pwd1+"'>Go Back to Original Bidding Items List</a>");
				pw.println("</form></body><html>");
			} else
			
			if(login==true) {
				
				session.setAttribute("uname", userName);
				session.setAttribute("pwd", pwd);
				pw.println("Welcome......."+session.getAttribute("uname"));
					
					map=service.getItemsDetails();
		
					Iterator<ItemsBean> itr=map.values().iterator();
					
					pw.println("<html><body><form name='form1'>");
					pw.println("<table border=1 align='center'>");
					pw.println("<tr><th>Item Id</th><th>Item Name</th><th>Item Price</th><th>Item Status</th>");
					pw.println("</tr>");
					
					while(itr.hasNext()) {
						ItemsBean bean=itr.next();
						int id=bean.getItemId();
						String itemName=bean.getItemName();
						double price=bean.getItemPrice();
						String status=bean.getItemStatus();
						pw.println("<tr>");
				
						pw.println("<td>"+id+"</td>");
						pw.println("<td>"+itemName+"</td>");
						pw.println("<td>"+price+"</td>");
						
						if(status.equals("available")){
							pw.println("<td><a href='LoginController?id="+id+"'>"+status+"</a></td>");
						} else {
							pw.println("<td>"+status+"</a></td>");
						}
						pw.println("</tr>");
					}
					
					pw.println("</table>");
					pw.println("</form></body><html>");
				
			} else {
				pw.println("<h2 align='center' bgcolor='red'>You are an invalid user, cannot access bidding site, contact admin for registration</h2>");
				RequestDispatcher dispatcher=request.getRequestDispatcher("index.html");
				dispatcher.include(request, response);
			}
		} catch (MyException e) {
			//pw.println("Error in processiong ur request! Plz try again");
			//request.getRequestDispatcher("error.html").include(request, response);
		}
	}
}
	
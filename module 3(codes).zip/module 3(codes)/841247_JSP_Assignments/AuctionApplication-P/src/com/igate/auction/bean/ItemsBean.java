package com.igate.auction.bean;

public class ItemsBean {
	private int itemId;
	private String itemName;
	private double itemPrice;
	private String itemStatus;
	public ItemsBean(int itemId, String itemName, double itemPrice,
			String itemStatus) {
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemStatus = itemStatus;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public double getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(double itemPrice) {
		this.itemPrice = itemPrice;
	}
	public String getItemStatus() {
		return itemStatus;
	}
	public void setItemStatus(String itemStatus) {
		this.itemStatus = itemStatus;
	}
	public ItemsBean() {
		super();
	}
	
	
}

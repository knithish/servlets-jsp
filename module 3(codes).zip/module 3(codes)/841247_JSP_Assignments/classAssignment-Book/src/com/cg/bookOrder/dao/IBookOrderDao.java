package com.cg.bookOrder.dao;

import com.cg.bookOrder.bean.Book;
import com.cg.bookOrder.exception.BookException;

public interface IBookOrderDao {


	public String getName(int isbn)throws BookException;
	public boolean validateDay(int noOfdays,int isbn)throws BookException;
	public int updateBookOrder(Book book)throws BookException;
	
	
	
	
}

package com.cg.bookOrder.controller;

import java.io.IOException;
import java.time.LocalDate;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.bookOrder.bean.Book;
import com.cg.bookOrder.exception.BookException;
import com.cg.bookOrder.service.BookOrderServiceImpli;
import com.cg.bookOrder.service.IBookOrderService;

/**
 * Servlet implementation class BookOrderServlet
 */
@WebServlet("/BookOrderServlet")
public class BookOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookOrderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String choice=request.getParameter("option");
		HttpSession session=request.getSession();
		IBookOrderService serviceObj=new BookOrderServiceImpli();
		
		if(choice!=null&&choice.equalsIgnoreCase("OrderBook"))
		{
			String isbn=request.getParameter("isbn");
			try {
				boolean resIsbn=serviceObj.isValidIsbn(isbn);
				if(resIsbn)
				{
					int bookISBN =Integer.parseInt(isbn);
					session.setAttribute("bookISBN",bookISBN);
					String name=null;
					name = serviceObj.getName(bookISBN);
					if(name!=null)
					{
						session.setAttribute("bookName", name);
						request.getRequestDispatcher("view/ViewDetails.jsp").forward(request, response);
					}
					
				}
			} catch (BookException e) {
				session.setAttribute("errMsg", e.getMessage());
				request.getRequestDispatcher("view/errorPage.jsp").forward(request, response);
			}
		}
		if(choice!=null&&choice.equalsIgnoreCase("Confirm")){
			
			String noOfDays=(String) request.getParameter("noOfDays");
			int minShipmentDays =Integer.parseInt(noOfDays);
			
			try {
				boolean res=serviceObj.validateDay(minShipmentDays, (int)session.getAttribute("bookISBN"));
				if(res==true)
				{
					int isbn=(int)session.getAttribute("bookISBN");
					LocalDate date=LocalDate.now();
					LocalDate startDate=date.plusDays(1);
					LocalDate endDate=startDate.plusDays(minShipmentDays);
					String description=request.getParameter("description");
					
					Book book=new Book(isbn,startDate,endDate,description,minShipmentDays);
					int updateRes=serviceObj.updateBookOrder(book);
					if(updateRes>0)
					{
						request.getRequestDispatcher("view/success.jsp").forward(request, response);
					}
				}
			} catch (BookException e) {
				session.setAttribute("errMsg", e.getMessage());
				request.getRequestDispatcher("view/errorPage.jsp").forward(request, response);
			}	
		}
		
	}

}

package com.cg.bookOrder.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.bookOrder.bean.Book;
import com.cg.bookOrder.dao.BookOrderDaoImpli;
import com.cg.bookOrder.dao.IBookOrderDao;
import com.cg.bookOrder.exception.BookException;
import com.sun.org.apache.xerces.internal.impl.xpath.regex.Match;


public class BookOrderServiceImpli implements IBookOrderService{
	IBookOrderDao daoObj=new BookOrderDaoImpli();
	@Override
	public String getName(int isbn) throws BookException {
		
		String bookName=daoObj.getName(isbn);
		return bookName;
		
	}

	@Override
	public boolean validateDay(int noOfdays, int isbn) throws BookException {
		boolean isTrueDay=daoObj.validateDay(noOfdays, isbn);
		return isTrueDay;
	}

	@Override
	public int updateBookOrder(Book book)throws BookException {
		int res=daoObj.updateBookOrder(book);
		return res;
		
	}

	@Override
	public boolean isValidIsbn(String isbn)throws BookException {
		
		Pattern ptrn=Pattern.compile("^[0-9]{6}$");
		Matcher match=ptrn.matcher(isbn);
		if(match.find())
		{
			return true;
		}
		else
			throw new BookException("Enter valid ISBN");
	}

}

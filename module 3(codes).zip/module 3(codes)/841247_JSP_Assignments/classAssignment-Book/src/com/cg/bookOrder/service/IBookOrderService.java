package com.cg.bookOrder.service;

import com.cg.bookOrder.bean.Book;
import com.cg.bookOrder.exception.BookException;

public interface IBookOrderService {

	String getName(int isbn) throws BookException;

	boolean validateDay(int noOfdays, int isbn) throws BookException;

	int updateBookOrder(Book book) throws BookException;

	boolean isValidIsbn(String isbn) throws BookException;


	

	
}

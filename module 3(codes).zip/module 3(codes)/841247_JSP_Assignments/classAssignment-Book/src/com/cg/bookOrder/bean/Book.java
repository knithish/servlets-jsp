package com.cg.bookOrder.bean;

import java.time.LocalDate;

public class Book {
	private int isbn;
	private LocalDate startDate;
	private LocalDate endDate;
	private String description;
	private int minShipmentDays;
	
	public int getIsbn() {
		return isbn;
	}
	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}
	public LocalDate getStartDate() {
		return startDate;
	}
	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}
	public LocalDate getEndDate() {
		return endDate;
	}
	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getMinShipmentDays() {
		return minShipmentDays;
	}
	public void setMinShipmentDays(int minShipmentDays) {
		this.minShipmentDays = minShipmentDays;
		
	}
	public Book(int isbn, LocalDate startDate, LocalDate endDate,
			String description, int minShipmentDays) {
		super();
		this.isbn = isbn;
		this.startDate = startDate;
		this.endDate = endDate;
		this.description = description;
		this.minShipmentDays = minShipmentDays;
	}
	

}

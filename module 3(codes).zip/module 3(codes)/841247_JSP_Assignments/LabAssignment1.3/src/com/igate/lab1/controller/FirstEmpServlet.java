package com.igate.lab1.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.assignment.dto.Employee;
import com.igate.assignment.service.EmployeeServiceImpl;
import com.igate.assignment.service.IEmployeeService;
import com.igate.lab1.exception.MyException;

/**
 * Servlet implementation class FirstEmpServlet
 */
@WebServlet("/FirstEmpServlet")
public class FirstEmpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static List<Employee> list=null;
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FirstEmpServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		//HttpSession session=request.getSession();
		String textVal=request.getParameter("textName");
		String value= request.getParameter("radioName");
		System.out.println(value);
		IEmployeeService service=new EmployeeServiceImpl();
		try {
			StringBuilder strBuild=service.isValid(value, textVal);
			if(strBuild.length()==0)
			{
			list=service.getDetails(value, textVal);
			//System.out.println(list);
			HttpSession session=request.getSession();
			session.setAttribute("List", list);
			request.getRequestDispatcher("FindData.jsp").include(request, response);
		/*	Iterator<Employee> itr=list.iterator();
			Employee emp = null;
			out.println("<html><body><table border='1'><tr><th>Employee Id</th><th>Employee Name</th><th>Department Id</th><th>Salary</th><th>location</th></tr>");
			while(itr.hasNext())
			{
				emp=itr.next();
				int id=emp.getEid();
				String name=emp.getName();
				int deptId=emp.getDeptid();
				int sal=emp.getSalary();
				String location=emp.getLocation();
				out.println("<tr><td>"+id+"</td>");
				out.println("<td>"+name+"</td>");
				out.println("<td>"+deptId+"</td>");
				out.println("<td>"+sal+"</td>");
				out.println("<td>"+location+"</td>");
				out.println("</tr>");
			}
			out.println("</table></body><html>");*/
			}
			else
			{
				HttpSession session=request.getSession();
				session.setAttribute("strBuild", strBuild);
				request.getRequestDispatcher("Error.jsp").include(request, response);
			}
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}

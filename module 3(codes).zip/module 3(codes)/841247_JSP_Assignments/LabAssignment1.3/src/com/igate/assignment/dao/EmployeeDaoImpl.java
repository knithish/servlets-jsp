package com.igate.assignment.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import com.igate.assignment.dto.Employee;
import com.igate.assignment.util.DbConnection;
import com.igate.lab1.exception.MyException;

public class EmployeeDaoImpl implements IEmployeeDao{
	String query;
	List<Employee> list = new ArrayList<>();
	@Override
	public List<Employee> getDetails(String id, String text) throws MyException {
		// TODO Auto-generated method stub
		
		
		Connection connection = null;
		ResultSet res = null;
		PreparedStatement pstat = null;
		try {
			if(id.equals("eid"))
				query="select * from employee where employeeid=?";
			if(id.equals("nameId"))
				query="select * from employee where employeename=?";
			if(id.equals("deptId"))
				query="select * from employee where deptnum=?";
			if(id.equals("locId"))
				query="select * from employee where location=?";
			connection = DbConnection.obtainConnection();
			pstat=connection.prepareStatement(query);
			pstat.setString(1,text);
			res=pstat.executeQuery();
			while(res.next())
			{
				int employeeid=res.getInt(1);
				String employeename=res.getString(2);
				int deptnum=res.getInt(3);
				int salary=res.getInt(4);
				String location=res.getString(5);
				Employee emp=new Employee(employeeid,employeename,deptnum,salary,location);
				//list=new ArrayList<>();
				list.add(emp);
				//System.out.println("list"+list);
			}
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println(list);
		return list;
	
}
}

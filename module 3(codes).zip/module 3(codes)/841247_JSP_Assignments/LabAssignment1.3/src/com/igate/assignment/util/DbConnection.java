package com.igate.assignment.util;
import java.sql.Connection;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import com.igate.lab1.exception.MyException;

public class DbConnection {
	static Connection connection;

	public static Connection obtainConnection() throws MyException {
		
		try {
			InitialContext context = new InitialContext();
			DataSource source = (DataSource) context
					.lookup("java:/OracleDS");
			connection = source.getConnection();
		} catch (NamingException e) {
			throw new MyException("Error while creating datascource::"
					+ e.getMessage());
		} catch (SQLException e) {
			throw new MyException("Error while obtaining connection::"
					+ e.getMessage());
		}
		return connection;
	}
}

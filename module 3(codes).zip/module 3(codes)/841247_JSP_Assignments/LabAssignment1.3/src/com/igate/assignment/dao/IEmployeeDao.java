package com.igate.assignment.dao;

import java.util.List;

import com.igate.assignment.dto.Employee;
import com.igate.lab1.exception.MyException;

public interface IEmployeeDao {
	List<Employee> getDetails(String id,String text) throws MyException;
}

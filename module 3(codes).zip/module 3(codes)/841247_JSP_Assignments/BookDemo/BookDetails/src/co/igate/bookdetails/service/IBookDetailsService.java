package co.igate.bookdetails.service;

import com.igate.bookdetails.bean.BookDetailsBean;
import com.igate.bookdetails.exception.MyException;

public interface IBookDetailsService 
{
	public boolean isValid(String isbn)throws MyException;
	public String getDetails(int locIsbn)throws MyException ;
	public void displayDetails(BookDetailsBean bean)throws MyException ;
	public int isValidDays(int isbn)throws MyException ;
}

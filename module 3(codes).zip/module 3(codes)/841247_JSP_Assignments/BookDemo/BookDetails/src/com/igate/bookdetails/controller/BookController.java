package com.igate.bookdetails.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.persistence.metamodel.SetAttribute;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.bookdetails.bean.BookDetailsBean;
import com.igate.bookdetails.exception.MyException;

import co.igate.bookdetails.service.BookDetailsServiceImpl;
import co.igate.bookdetails.service.IBookDetailsService;



@WebServlet("/BookController")
public class BookController extends HttpServlet 
{
	private static final long serialVersionUID = 1L;



	public BookController() 
	{
		super();


	}



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{

		doPost(request, response);

	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String isbn=request.getParameter("isbn");
		IBookDetailsService service=new BookDetailsServiceImpl();
		HttpSession session=request.getSession();
		BookDetailsBean bean=null;
		PrintWriter out=response.getWriter();
		

		try 
		{

			String option=request.getParameter("option");
			
			if(option!=null && option.equals("Order"))
			{
				
				String days=request.getParameter("nodays");
				
				int noOfDays=Integer.parseInt(days);
				String desc=request.getParameter("txtName");
				
				int isbnNumber=(int) session.getAttribute("locIsbn");
				bean=new BookDetailsBean(isbnNumber, desc, noOfDays);
				
				
				int validDays=service.isValidDays(isbnNumber);
				
				
				
				
				if(noOfDays>validDays)
				{
					
					service.displayDetails(bean);
					request.getRequestDispatcher("view/success1.jsp").forward(request, response);
				}
				else
				{
					
					out.println("invalid no of days");
					request.getRequestDispatcher("view/error.jsp").include(request, response);
				}
			}
				else if(service.isValid(isbn))
				{
					Integer locIsbn=Integer.parseInt(isbn);
					if(locIsbn>=0)
					{
						
						String bookName=service.getDetails(locIsbn);
						session.setAttribute("locIsbn", locIsbn);
						session.setAttribute("bookName", bookName);
						request.getRequestDispatcher("view/success.jsp").forward(request, response);;
					}
				}

			
		}

		catch (MyException e)
		{
			session.setAttribute("errMsg", e.getMessage() );
			request.getRequestDispatcher("view/error.jsp").forward(request, response);
		}



	}

}

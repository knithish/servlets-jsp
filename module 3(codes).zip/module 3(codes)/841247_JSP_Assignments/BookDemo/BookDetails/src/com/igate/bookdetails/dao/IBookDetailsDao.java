package com.igate.bookdetails.dao;

import com.igate.bookdetails.bean.BookDetailsBean;
import com.igate.bookdetails.exception.MyException;

public interface IBookDetailsDao 
{
	public String getConection(int locIsbn)throws MyException;
	public void displayDetails(BookDetailsBean bean)throws MyException;
	public int isValidDays(int isbn)throws MyException;
}

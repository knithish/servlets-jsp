package com.igate.bookdetails.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.igate.bookdetails.bean.BookDetailsBean;
import com.igate.bookdetails.exception.MyException;
import com.igate.bookdetails.util.DBUtilConnection;


public class BookDetailsDaoImpl implements IBookDetailsDao
{
	Connection con=null;
	PreparedStatement prepare=null;
	ResultSet res=null;

	@Override
	public String getConection(int locIsbn)throws MyException
	{
		String bookName = null;
		try 
		{
			con=DBUtilConnection.obtainConnection();
			String query1="SELECT book_name from book_details where bookisbn=?";
			System.out.println("after select");
			prepare=con.prepareStatement(query1);
			prepare.setInt(1,locIsbn);
			res=prepare.executeQuery();
			
			while(res.next())
			{
				bookName=res.getString(1);
			}
		}
		catch ( SQLException e)
		{
			throw new MyException("error while selecting the book_name"+e.getMessage());
		}
		return bookName;
	}

	@Override
	public void displayDetails(BookDetailsBean bean)throws MyException 
	{
		try
		{
			con=DBUtilConnection.obtainConnection();
			LocalDate date=LocalDate.now();
			LocalDate startDate=date.plusDays(1);
			LocalDate endDate=date.plusDays(bean.getNoOfDays());
			String query2="INSERT INTO book_shipment_details values(?,?,?,?,?)";
			prepare=con.prepareStatement(query2);
			prepare.setInt(1,bean.getBookIsbn());
			prepare.setDate(2,Date.valueOf(startDate));
			prepare.setDate(3, Date.valueOf(endDate));
			prepare.setString(4, bean.getDescription());
			prepare.setInt(5, bean.getNoOfDays());
			prepare.executeUpdate();
			
		} 
		catch ( SQLException e) 
		{
			throw new MyException("error while inserting"+e.getMessage());
			
		}

	}

	@Override
	public int isValidDays(int isbn)throws MyException
	{
		int locdays=0;
		try 
		{
			con=DBUtilConnection.obtainConnection();
			String query3="SELECT MIN_SHIPMENT_DAYS from book_details where BOOKISBN=?";
			prepare=con.prepareStatement(query3);
			prepare.setInt(1, isbn);
			res=prepare.executeQuery();
			while(res.next()) {
				locdays=res.getInt(1);
			}
		} 
		catch ( SQLException e) 
		{
			throw new MyException("invalid days"+e.getMessage());
		}
		return locdays;
	}
}

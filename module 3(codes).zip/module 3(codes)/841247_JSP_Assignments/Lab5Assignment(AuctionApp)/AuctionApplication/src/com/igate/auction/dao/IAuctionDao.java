package com.igate.auction.dao;

import java.util.Map;
import java.util.Set;

import com.igate.auction.bean.AuctionBean;
import com.igate.auction.bean.UserBean;
import com.igate.auction.exception.MyException;

public interface IAuctionDao {
	
	
	public boolean isValidUser(UserBean bean)throws MyException;
	public Map<String, AuctionBean> populateTable()throws MyException;
	public Map<String, AuctionBean> biddingTable(String idValue)throws MyException;
	public int updateDB(String itemId)throws MyException;
	public Map<String, AuctionBean> displayDB(String itemId) throws MyException;
}

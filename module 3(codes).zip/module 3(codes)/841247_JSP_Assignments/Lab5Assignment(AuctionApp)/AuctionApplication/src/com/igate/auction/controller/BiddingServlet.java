package com.igate.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.auction.bean.AuctionBean;
import com.igate.auction.exception.MyException;
import com.igate.auction.service.AuctionServiceImpl;
import com.igate.auction.service.IAuctionService;

/**
 * Servlet implementation class BiddingServlet
 */
@WebServlet("/BiddingServlet")
public class BiddingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       AuctionBean aBean;
       String option;
       
      
          /**
     * @see HttpServlet#HttpServlet()
     */
    public BiddingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession ses=request.getSession();
		PrintWriter out=response.getWriter();
	
		String name=(String)ses.getAttribute("name");
		String idValue=request.getParameter("id");

		String startHtml="<html><head></head><body>";
		String endHtml="</body></html>";
		out.println(startHtml+"<b>Welcome....."+name+"</b></br>"
				+ "<center><form action='ConfirmServlet' method='post'><table border=\"1\">"+
				"<thead>"+
				"<tr>"+
				"<th> Item Id </th>"+
				"<th> Item Name </th>"+
				"<th> ItemPrice </th>"+
				"<th> Item Status </th>"+
				"<th> Remove </th>"+
				"</tr>"+	
				"</thead>");
		IAuctionService implObj=new AuctionServiceImpl();
		try {
			HttpSession session=request.getSession();
			Map<String, AuctionBean> mapAuction=null;
			if(request.getParameter("bidValue")!=null)
			{
				mapAuction =(Map<String, AuctionBean>) session.getAttribute("biddingCart");
				
			}
				
			else
			{
				mapAuction=implObj.biddingTableValues(idValue);
			}
			
			session.setAttribute("biddingCart", mapAuction);
			
			Set <Entry<String,AuctionBean>> value=mapAuction.entrySet();
			Iterator<Entry<String, AuctionBean>> itr=value.iterator();
			while(itr.hasNext())
			{	
				Map.Entry<String,AuctionBean> me=(Entry<String, AuctionBean>)itr.next();
			
				aBean = (AuctionBean) me.getValue();
				
		
				if(mapAuction!=null)
				{
					
						out.println("<tbody>"+
						"<tr>"+
						"<td>"+aBean.getItemId()+"</td>"+
						"<td>"+aBean.getItemName()+"</td>"+
						"<td>"+aBean.getItemPrice()+"</td>"+
						"<td>"+aBean.getItemStatus()+"</td>"+
						"<td><a href='RemoveServlet?id="+aBean.getItemId()+"'>RemoveFromList</a></td>");
				}
				
				out.println("</tr></tbody>");
			
			}
			out.println("<tr ><td colspan=2><input type=\"submit\" value=\"Confirm Bidding\"></td>"
					+ "<td colspan=3><a href='SuccessServlet'>Go Back to Original Bidding Items list</a></td></tr>");
			

			out.println("</table></form></center>");
		} catch (MyException e) {
			// TODO Auto-generated catch block
			
		}
		out.println(endHtml);

	}	

}







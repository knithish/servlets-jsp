package com.igate.auction.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.igate.auction.bean.AuctionBean;
import com.igate.auction.bean.UserBean;
import com.igate.auction.exception.MyException;
import com.igate.auction.util.DBConnectionUtil;

public class AuctionDaoImpli implements IAuctionDao{

	static Map<String, AuctionBean>auctionMap=new HashMap<>();
	DBConnectionUtil dbConn=new DBConnectionUtil();
	AuctionBean aBean;
	public boolean isValidUser(UserBean uBean)throws MyException
	{
		Connection conObj=DBConnectionUtil.obtainConnection();
		try {

			String name=uBean.getUserName();
			String pwd=uBean.getPassword();	
			PreparedStatement pStmt=conObj.prepareStatement("select username,password from login where username=? and password=?");
			pStmt.setString(1, name);
			pStmt.setString(2, pwd);
			ResultSet result=pStmt.executeQuery();
			boolean re=result.next();
			if(re==true)
			{
				return true;
			}
			else
				return false;

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MyException(e.toString());
		}

	}


	public Map<String, AuctionBean>populateTable()throws MyException{
		Map<String, AuctionBean>auctionMap=new HashMap<>() ;
		Connection conObj;
		try {
			conObj = DBConnectionUtil.obtainConnection();

			PreparedStatement stmt=conObj.prepareStatement("select itemid,itemname,itemprice,status from itemsforbid");
			ResultSet res=stmt.executeQuery();
			while(res.next())
			{
				
				String locItemId=res.getString(1);
				String locItemName=res.getString(2);
				String locItemPrice=res.getString(3);
				String locStatus=res.getString(4);
				aBean=new AuctionBean(locItemId,locItemName,locItemPrice,locStatus);
				auctionMap.put(res.getString("itemid"),aBean );
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MyException(e.toString());
		}
		return auctionMap;
	}
	
	
	public Map<String, AuctionBean>biddingTable(String itemId)throws MyException{
		
		Connection conObj;
		try {
			conObj = DBConnectionUtil.obtainConnection();

			PreparedStatement stmt=conObj.prepareStatement("select itemid,itemname,itemprice,status from itemsforbid where itemid=?");
			stmt.setString(1, itemId);
			ResultSet res=stmt.executeQuery();
			while(res.next())
			{
				
				String locItemId=res.getString(1);
				String locItemName=res.getString(2);
				String locItemPrice=res.getString(3);
				String locStatus=res.getString(4);
				aBean=new AuctionBean(locItemId,locItemName,locItemPrice,locStatus);
				auctionMap.put(res.getString("itemid"),aBean );
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new MyException(e.toString());
		}
		return auctionMap;
		
	}

	public int updateDB(String itemId) throws MyException
	{
		Connection conObj;
		try {
			conObj = DBConnectionUtil.obtainConnection();
			
			PreparedStatement stmt=conObj.prepareStatement("update itemsforbid set status='unavailable' where itemid=?");
			stmt.setString(1, itemId);
			int rowCount=stmt.executeUpdate();
			if(rowCount<=0)
			{
				throw new MyException("could not update the database");
			}
			
			return rowCount;
		}catch(SQLException e)
			{
				throw new MyException("eroor while selecting from database");
			}

	}


	@Override
	public Map<String, AuctionBean> displayDB(String itemId) throws MyException {
		// TODO Auto-generated method stub
		Connection conObj;
		try {
			conObj = DBConnectionUtil.obtainConnection();
			
			PreparedStatement stmt=conObj.prepareStatement("select itemid,itemname,itemprice,status from itemsforbid where itemid=?");
			stmt.setString(1, itemId);
			ResultSet res=stmt.executeQuery();
			while(res.next())
			{
				
				String locItemId=res.getString(1);
				String locItemName=res.getString(2);
				String locItemPrice=res.getString(3);
				String locStatus=res.getString(4);
				aBean=new AuctionBean(locItemId,locItemName,locItemPrice,locStatus);
				auctionMap.put(res.getString("itemid"),aBean );
			}
		
	}catch(SQLException e)
		{
			throw new MyException("error while selecting from database");
		}
		return auctionMap;
		
		
}
}
package com.igate.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.igate.auction.bean.AuctionBean;
import com.igate.auction.exception.MyException;
import com.igate.auction.service.AuctionServiceImpl;
import com.igate.auction.service.IAuctionService;

/**
 * Servlet implementation class SuccessServlet
 */
@WebServlet("/SuccessServlet")
public class SuccessServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;
AuctionBean aBean;
static String name;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SuccessServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter out=response.getWriter();
		name=request.getParameter("userName");
		String startHtml="<html><head></head><body>";
		String endHtml="</body></html>";
		out.println(startHtml+"<b>Welcome....."+name+"</b></br>"
				+ "<center><table border=\"1\">"+
				"<thead>"+
				"<tr>"+
				"<th> Item Id </th>"+
				"<th> Item Name </th>"+
				"<th> ItemPrice </th>"+
				"<th> Item Status </th>"+
				"</tr>"+	
				"</thead>");
		IAuctionService implObj=new AuctionServiceImpl();
		try {
			Map<String,AuctionBean> mapAuction=implObj.populateTheTable();
			Set <Entry<String,AuctionBean>> value=mapAuction.entrySet();
			Iterator<Entry<String, AuctionBean>> itr=value.iterator();
			while(itr.hasNext())
			{
				Map.Entry<String,AuctionBean> me=(Entry<String, AuctionBean>)itr.next();
				aBean = (AuctionBean) me.getValue();
				String stat=aBean.getItemStatus();
				out.println("<tbody>"+
						"<tr>"+
						"<td>"+aBean.getItemId()+"</td>"+
						"<td>"+aBean.getItemName()+"</td>"+
						"<td>"+aBean.getItemPrice()+"</td>"
						+"<td><a href='BiddingServlet?id="+aBean.getItemId()+"'>"+stat+"</a></td>");
				out.println("</tr></tbody>");
			}
			out.println("</table></center>");
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		out.println(endHtml);


	}

}

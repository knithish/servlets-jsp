
package com.igate.auction.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.igate.auction.bean.UserBean;
import com.igate.auction.exception.MyException;
import com.igate.auction.service.AuctionServiceImpl;
import com.igate.auction.service.IAuctionService;

/**
 * Servlet implementation class AuctionServlet
 */
@WebServlet("/AuctionServlet")
public class AuctionServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	static String name;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AuctionServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession ses=request.getSession();
	
		name=request.getParameter("userName");
	
		ses.setAttribute("name",name);
		String pwd=request.getParameter("password");
		UserBean bean=new UserBean(name,pwd);
		IAuctionService impliObj=new AuctionServiceImpl();
		try {
			boolean valid=impliObj.isValidDetails(bean);
			if(valid==true)
			{
				RequestDispatcher dispatcher=request.getRequestDispatcher(""
						+ "SuccessServlet");
				dispatcher.forward(request, response);
			}
			else
			{
				PrintWriter out=response.getWriter();
				out.println("<html><body><center><b><marquee>You are an  invalid user,cannot access biding site,"
						+ "contact admin for registration</marquee></b></center></body></html>");
				RequestDispatcher dispatcher=request.getRequestDispatcher("Login.html");
				dispatcher.include(request, response);
			}
			
		} catch (MyException e) {
			// TODO Auto-generated catch block
			//set attribute and send to error
		}
		
		
		
		
		
		
		
		
	}

}

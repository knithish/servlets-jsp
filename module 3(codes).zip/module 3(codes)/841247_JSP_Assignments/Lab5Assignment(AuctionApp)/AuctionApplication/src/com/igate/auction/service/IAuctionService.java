package com.igate.auction.service;

import java.util.Map;
import java.util.Set;

import com.igate.auction.bean.AuctionBean;
import com.igate.auction.bean.UserBean;
import com.igate.auction.exception.MyException;

public interface IAuctionService {
	
	public boolean isValidDetails(UserBean bean)throws MyException;
	public Map<String, AuctionBean> populateTheTable()throws MyException;
	public Map<String, AuctionBean> biddingTableValues(String idValue) throws MyException;
	public Map<String, AuctionBean> displayDB(String itemId) throws MyException;
	public int updateDBService(String itemId)throws MyException;
}

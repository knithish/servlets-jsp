package com.igate.auction.service;

import java.util.Map;
import java.util.Set;

import com.igate.auction.bean.AuctionBean;
import com.igate.auction.bean.UserBean;
import com.igate.auction.dao.AuctionDaoImpli;
import com.igate.auction.dao.IAuctionDao;
import com.igate.auction.exception.MyException;

public class AuctionServiceImpl implements IAuctionService {
	IAuctionDao daoObj=new AuctionDaoImpli();
	public boolean isValidDetails(UserBean bean)throws MyException
	{
		
		
		boolean res=daoObj.isValidUser(bean);
		return res;
	}
	
	public Map<String, AuctionBean> populateTheTable()throws MyException{
		
		Map<String, AuctionBean> mapValues=daoObj.populateTable();
		return mapValues;
		
	}

	public Map<String, AuctionBean> biddingTableValues(String idValue)throws MyException {
		// TODO Auto-generated method stub
		Map<String, AuctionBean> mapValues= daoObj.biddingTable(idValue);
		return mapValues;
		
	}



	@Override
	public int updateDBService(String itemId) throws MyException {
		// TODO Auto-generated method stub
		int rowCount=daoObj.updateDB(itemId);
		return rowCount;
		
	}

	@Override
	public Map<String, AuctionBean> displayDB(String itemId) throws MyException {
		Map<String,AuctionBean> mapAuction=daoObj.displayDB(itemId);
		return mapAuction;
	}
	
	
	
}

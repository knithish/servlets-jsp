package com.igate.hotelreservation.service;

public interface IHotelService 
{
	public void getConnection();
}

package com.igate.lab5.service;

import java.util.Map;
import java.util.Set;

import com.igate.lab5.bean.ItemBean;

public interface IAuctionService 
{
	public boolean getConnection(String username,String password);
	public Map<Integer,ItemBean> getDetails();
	public Map<Integer,ItemBean> getItemsSelected(int itemId);
	
}

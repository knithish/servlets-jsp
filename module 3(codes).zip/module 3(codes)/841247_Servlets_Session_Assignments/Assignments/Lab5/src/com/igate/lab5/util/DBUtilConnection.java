package com.igate.lab5.util;


import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DBUtilConnection 
{


	static Connection connection;

	public static Connection obtainConnection()
	{
		try 
		{
			InitialContext context = new InitialContext();
			DataSource source = (DataSource) context.lookup("java:/OracleDS");
			connection = source.getConnection();
		} 
		catch (NamingException e) 
		{
			//throw new MyException("");
		} catch (SQLException e) 
		{
			//throw new MyException("");
		}
		return connection;

	}

}

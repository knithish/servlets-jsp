package com.igate.lab5.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.LinkedHashSet;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.igate.lab5.bean.ItemBean;
import com.igate.lab5.bean.LoginBean;
import com.igate.lab5.service.AuctionServiceImpl;
import com.igate.lab5.service.IAuctionService;


@WebServlet("/ControllerServlet")
public class ControllerServlet extends HttpServlet 
{
	
	private static final long serialVersionUID = 1L;
       
    
    public ControllerServlet() 
    {
        super();


    }



	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{


	}



	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		String username=request.getParameter("usrname");
		String password=request.getParameter("psswd");
		
		IAuctionService service=new AuctionServiceImpl();
		boolean result=service.getConnection(username,password);
		
		if(result==true)
		{
			
			RequestDispatcher reqDis=request.getRequestDispatcher("SuccessController");
			reqDis.forward(request,response);
		}
		else
		{
			out.println("You are an invalid user,cannot access bidding site,contact admin for registration!...");
			RequestDispatcher reqDis=request.getRequestDispatcher("LoginPage.html");
			reqDis.include(request,response);
			
		}
		
	
	}
}

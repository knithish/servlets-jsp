package com.igate.lab5.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.igate.lab5.bean.ItemBean;
import com.igate.lab5.service.AuctionServiceImpl;
import com.igate.lab5.service.IAuctionService;



@WebServlet("/BiddingCart")
public class BiddingCart extends HttpServlet
{
	private static final long serialVersionUID = 1L;
       
    
    public BiddingCart() 
    {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter out=response.getWriter();
		String name1= request.getParameter("usrname");
		out.println("Welcome!!!..."+name1);
		
		out.println("<body>");
		out.println("<table border='1'>");
		out.println("<tr>");
		out.println("<th>Item ID</th>");
		out.println("<th>Item Name</th>");
		out.println("<th>Item Price</th>");
		out.println("<th>Item Status</th>");
		out.println("<th>Remove</th>");
		out.println("</tr>");
		ItemBean item=null;
		String itemId=request.getParameter("id1");
		int id2=Integer.parseInt(itemId);
		Map<Integer,ItemBean> map1=new HashMap<Integer,ItemBean>();
		IAuctionService service=new AuctionServiceImpl();
		map1=service.getItemsSelected(id2);
		Iterator<ItemBean> itr=map1.values().iterator();
		while(itr.hasNext())
		{
			item=itr.next();
			int itemid=item.getItemId();
			String itemName=item.getItemName();
			int itemPrice=item.getItemPrice();
			String status=item.getStatus();
			
			out.println("<td>"+itemid+"</td>");
			out.println("<td>"+itemName+"</td>");
			out.println("<td>"+itemPrice+"</td>");
			out.println("<td>"+status+"</td>");
			out.println("<td><a href=''>Remove from bidding cart</a></td>");
			out.println("</tr>");
		}
	}
}

package com.igate.lab5.bean;

public class ItemBean 
{
	
	int itemId;
	String itemName;
	int itemPrice;
	String status;
	
	public ItemBean(int itemId, String itemName, int itemPrice, String status) 
	{
		super();
		this.itemId = itemId;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.status = status;
	}
	public int getItemId()
	{
		return itemId;
	}

	public void setItemId(int itemId) 
	{
		this.itemId = itemId;
	}

	public String getItemName() 
	{
		return itemName;
	}

	public void setItemName(String itemName)
	{
		this.itemName = itemName;
	}

	public int getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(int itemPrice) 
	{
		this.itemPrice = itemPrice;
	}

	public String getStatus() 
	{
		return status;
	}

	public void setStatus(String status) 
	{
		this.status = status;
	}

	
}

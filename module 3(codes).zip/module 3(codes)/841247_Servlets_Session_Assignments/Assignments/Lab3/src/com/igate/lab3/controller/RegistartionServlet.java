package com.igate.lab3.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.igate.lab3.bean.RegistrationBean;
import com.igate.lab3.service.IRegistrationService;
import com.igate.lab3.service.RegistarationServiceImpl;

/**
 * Servlet implementation class RegistartionServlet
 */
@WebServlet("/RegistartionServlet")
public class RegistartionServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistartionServlet() 
    {
        super();


    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String fstName=request.getParameter("fstname");
		String lstName=request.getParameter("lstname");
		String password=request.getParameter("psswd");
		RegistrationBean bean =new RegistrationBean(fstName,lstName,password);
		/*String gender=request.getParameter("radiobtn");
		String skill=request.getParameter("chkbox");
		String city=request.getParameter("city");*/
		IRegistrationService service=new RegistarationServiceImpl();
		service.getConnection(bean);
		
	}

}

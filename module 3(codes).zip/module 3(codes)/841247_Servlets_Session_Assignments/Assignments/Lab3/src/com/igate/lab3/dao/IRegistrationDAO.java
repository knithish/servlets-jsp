package com.igate.lab3.dao;

import com.igate.lab3.bean.RegistrationBean;

public interface IRegistrationDAO 
{
	public void getConnection(RegistrationBean bean);
}

package com.igate.lab3.service;

import com.igate.lab3.bean.RegistrationBean;
import com.igate.lab3.dao.IRegistrationDAO;
import com.igate.lab3.dao.RegistartionDaoImpl;

public class RegistarationServiceImpl implements IRegistrationService
{

	@Override
	public void getConnection(RegistrationBean bean)
	{
		IRegistrationDAO dao=new RegistartionDaoImpl();
		dao.getConnection(bean);
		
	}
	
}

package com.igate.day4.ServletDemo;

import java.io.IOException;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.annotation.WebInitParam;

/**
 * Servlet Filter implementation class FilterPerformance
 */
@WebFilter(
		urlPatterns = { "/Servlet1Demo" }, 
		initParams = { 
				@WebInitParam(name = "Fruits", value = "apple,banana,grapes")
		})
public class FilterPerformance implements Filter {

    /**
     * Default constructor. 
     */
    public FilterPerformance() 
    {


    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() 
	{
		// TODO Auto-generated method stub
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException 
	{
		long time1=System.currentTimeMillis();
		System.out.println("Before processing:"+time1);
		chain.doFilter(request, response);
		//Date time2=new Date();
		long time2=System.currentTimeMillis();
		
		System.out.println("After Processing:"+(time2-time1));
		
	}

	
	public void init(FilterConfig fConfig) throws ServletException 
	{
		fConfig.getInitParameter("Fruits");
	}

}

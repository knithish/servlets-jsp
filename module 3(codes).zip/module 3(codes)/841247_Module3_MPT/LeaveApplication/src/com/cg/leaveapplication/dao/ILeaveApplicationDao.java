package com.cg.leaveapplication.dao;

import com.cg.leaveapplication.bean.UpdateDetailsBean;
import com.cg.leaveapplication.exception.MyException;

public interface ILeaveApplicationDao
{
	public String getConnection(int empId)throws MyException;
	public int updateDetails(UpdateDetailsBean bean)throws MyException;
}

package com.cg.leaveapplication.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.leaveapplication.bean.UpdateDetailsBean;
import com.cg.leaveapplication.exception.MyException;
import com.cg.leaveapplication.util.DBUtilConnection;

public class LeaveApplicationDapImpl implements ILeaveApplicationDao
{
	Connection con=null;
	PreparedStatement prepare=null;
	ResultSet res=null;
	
	//---------------- 1. Retrieve Employee name  ---------------
		/**************************************************************
		 - Method Name		:	getConnection()
		 - Input Parameters	:	employee Id
		 - Return Type		:	String
		 - Throws			:   MyException
		 - Author			:	Employee-ID: 841247
		 - Creation Date	:	26/02/2016
		 - Description		:	validate employee id and return employee name
		 *************************************************************/	
	@Override
	public String getConnection(int empId)throws MyException 
	{
		con=DBUtilConnection.obtainConnection();
		String query1="SELECT ENAME from employee_details1 where EMPID=?";
		try 
		{
			prepare=con.prepareStatement(query1);
			prepare.setInt(1, empId);
			int count=prepare.executeUpdate();
			res=prepare.executeQuery();
			String name=null;
			if(count<=0)
			{
				throw new MyException("No rows selected....Enter proper Employee ID ");
			}
			else
			{
				while(res.next())
				{
					name=res.getString(1);
				}
				return name;
			}
		} 
		catch (SQLException e) 
		{
			throw new MyException("Error while selecting values from database...ERROR MESSAGE::"+e.getMessage());
		}
		finally
		{
			try
			{
				if(con!=null)
				{
					if(prepare!=null)
					{
						if(res!=null)
						{
							res.close();
						}
						prepare.close();
					}
					con.close();
				}
			}
			catch(SQLException e)
			{
				throw new MyException("Could not close the connection");
			}
		}
		
	}
	
	
	//---------------- 2. Insert into employee_leave_details table  ---------------
			/**************************************************************
			 - Method Name		:	updateDetails()
			 - Input Parameters	:	UpdateDetailsBean bean
			 - Return Type		:	int
			 - Throws			:   MyException
			 - Author			:	Employee-ID: 841247
			 - Creation Date	:	26/02/2016
			 - Description		:	insert the details into the database
			 *************************************************************/	

	@Override
	public int updateDetails(UpdateDetailsBean bean) throws MyException
	{
		con=DBUtilConnection.obtainConnection();
		int updateRes=0;
		
		String query2="INSERT INTO employee_leave_details VALUES(?,?,?,?,?)";
		
		try 
		{
			
			prepare=con.prepareStatement(query2);
			prepare.setInt(1, bean.getEid());
			prepare.setDate(2,java.sql.Date.valueOf(bean.getStartDate()));
			prepare.setDate(3,java.sql.Date.valueOf(bean.getEndDate()));
			prepare.setString(4, bean.getDescription());
			prepare.setInt(5, bean.getLeavesApplied());
			updateRes=prepare.executeUpdate();
			if(updateRes<=0)
			{
				throw new MyException("could not update the database");
			}
			else
			{
				return updateRes;
			}
			
		} 
		catch (SQLException e) 
		{
			throw new MyException("Error while selecting values from database...ERROR MESSAGE::"+e.getMessage());
		}
		
		finally
		{
			try{
				if(con!=null)
				{
					if(prepare!=null)
					{
						if(res!=null)
						{
							res.close();
						}
						prepare.close();
					}
					con.close();
				}
			}catch(SQLException e)
			{
				throw new MyException("Could not close the connection");
			}
		}
	}
}



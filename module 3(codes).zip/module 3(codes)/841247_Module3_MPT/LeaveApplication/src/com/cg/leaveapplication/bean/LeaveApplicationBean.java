package com.cg.leaveapplication.bean;

/**
 * EmpID 		: 841247
 * Class Name 	: LeaveApplicationBean 
 * Package 		: com.cg.leaveapplication.bean 
 * Date 		: 26/02/2016
 */
public class LeaveApplicationBean 
{
	public String getEmpName() 
	{
		return empName;
	}
	public void setEmpName(String empName)
	{
		this.empName = empName;
	}
	public int getLeaves() 
	{
		return leaves;
	}
	public void setLeaves(int leaves)
	{
		this.leaves = leaves;
	}
	public LeaveApplicationBean(String empName, int leaves) 
	{
		super();
		this.empName = empName;
		this.leaves = leaves;
	}
	private String empName;
	private int leaves;
}

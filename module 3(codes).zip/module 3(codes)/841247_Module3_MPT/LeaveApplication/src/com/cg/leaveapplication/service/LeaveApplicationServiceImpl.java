package com.cg.leaveapplication.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.leaveapplication.bean.UpdateDetailsBean;
import com.cg.leaveapplication.dao.ILeaveApplicationDao;
import com.cg.leaveapplication.dao.LeaveApplicationDapImpl;
import com.cg.leaveapplication.exception.MyException;

/**
 * Employee ID	:	841247
 * Class Name	:	LeaveApplicationServiceImpl
 * Package		:	com.igate.leaveapplication.service
 * Date			:	26/02/2016
 */

public class LeaveApplicationServiceImpl implements ILeaveApplicationservice
{
	ILeaveApplicationDao dao=new LeaveApplicationDapImpl();
	
	@Override
	public boolean isValid(String empid) throws MyException
	{
		Pattern ptrn=Pattern.compile("^[0-9]+$");
		Matcher match=ptrn.matcher(empid);
		if(match.find())
		{
			return true;
		}
		else
			throw new MyException("Enter valid Employee ID");
	}
	
	@Override
	public String getConnection(int empId) throws MyException 
	{
		
		String name=dao.getConnection(empId);
		return name;
		
	}

	@Override
	public int updateDetails(UpdateDetailsBean bean)throws MyException 
	{
		int res=dao.updateDetails(bean);

		return res;
	}

	
	
}

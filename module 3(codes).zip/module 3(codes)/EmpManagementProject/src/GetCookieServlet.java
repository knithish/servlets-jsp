

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "GetCookieServletName", urlPatterns = { "/GetCookieServletMap" })
public class GetCookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public GetCookieServlet() {
        super();
        System.out.println("Get Cookie Servlet constructor");
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Get Cookie Servlet init()");
	}

	
	public void destroy() {
		System.out.println("Get Cookie Servlet destroy()");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		
		Cookie cookA[]=request.getCookies();
		if(cookA==null)
		{
			out.println("No cookies are set by browser");
		}
		else
		{
			for(int i=0;i<cookA.length;i++)
			{
				String cookName=cookA[i].getName();
				String cookVal=cookA[i].getValue();
				
				out.println("<br>Cookie Name is: "+cookName);
				out.println("<br>Cookie Value is: "+cookVal);
			}
		}
	}

}

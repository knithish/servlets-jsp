

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

@WebServlet(name = "LoggerServletName", 
			urlPatterns = { "/LoggerServletMap" },
			initParams={ @WebInitParam(name="propFileName",value="logger.properties")})
public class LoggerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	ServletConfig cg;
    public LoggerServlet() {
        super();
        System.out.println("Logger Servlet constructor");
    }

	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		cg=config;
		System.out.println("Logger Servlet init()");
	}

	public void destroy() {
		System.out.println("Logger Servlet destroy()");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String fileName=cg.getInitParameter("propFileName");
		ServletContext ctx=cg.getServletContext();
		String path=ctx.getRealPath("/WEB-INF/"+fileName);
		PropertyConfigurator.configure(path);
		Logger log=Logger.getLogger("ServletLogger.class");
		
		log.info("Info Message logged in Log file");
		log.error("Error Message was logged in Loged file");
		PrintWriter pw=response.getWriter();
		pw.println("Hello From LoggerServlet");
		pw.println("<br>Logger Name is: "+log.getName());
	}

}



import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "AddCookieServletName", urlPatterns = { "/AddCookieServletMap" })
public class AddCookieServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	int count;
    public AddCookieServlet() {
        super();
        System.out.println("Add Cookie Servlet constructor");
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("Add Cookie Servlet init()");
	}

	
	public void destroy() {
		System.out.println("Add Cookie Servlet destroy()");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		Cookie cookieArray[]=request.getCookies();
		
		String name=request.getParameter("txtName");//txtName is the name of input tag of type text
		
		if(cookieArray==null)
		{
			count=1;
			String cn="User"+count;
			Cookie myCookie=new Cookie(cn, name);
			response.addCookie(myCookie);
			System.out.println("First Cookie Added........");
			pw.println("First Cookie Added........");
			
		}
		else
		{
			count=cookieArray.length;
			count++;
			String cn="User"+count;
			Cookie myCookie=new Cookie(cn, name);
			response.addCookie(myCookie);
			System.out.println("Next Cookie Added........");
			pw.println("Next Cookie Added........");
		}
		pw.println("<hr/><a href='GetCookieServletMap'>");
		pw.println("Get Cookies </a>");
	}

}

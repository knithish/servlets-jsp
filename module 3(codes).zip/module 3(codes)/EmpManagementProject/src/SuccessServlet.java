

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "SuccessServletName",
			urlPatterns = { "/SuccessServletMap" },
			initParams={@WebInitParam(name="CompEmail",value="hr@capgemini.com")})
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    ServletConfig cg;
    public SuccessServlet() {
        super();
        System.out.println("In success servlet constructor");
        
    }

	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		cg=config;
		System.out.println("In success servlet init()");
	}

	
	public void destroy() {
		System.out.println("In success servlet destroy()");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//Get init param data
		String emailAdd=cg.getInitParameter("CompEmail");
		String username=(String)request.getAttribute("UNobj");
		PrintWriter pw=response.getWriter();
		ServletContext ctx=cg.getServletContext();
		String compLocation=ctx.getInitParameter("Location");
		RequestDispatcher rdHeader=ctx.getRequestDispatcher("/HTML/Header.html");
		RequestDispatcher rdFooter=ctx.getRequestDispatcher("/HTML/Footer.html");
		rdHeader.include(request,response);
		pw.println("<h2> Welcome you are valid User </h2>"+"Welcome "+username);
		pw.println("<br>Our company HR Email is:"+emailAdd);
		pw.write("<br>Our Location is:"+compLocation);
		pw.println("<br><a href='RedirectDemoServletMap'>Redirect To Google</a>");
		rdFooter.include(request,response);
	}

}

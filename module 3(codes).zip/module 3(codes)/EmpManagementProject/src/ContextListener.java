import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;
//It is Listener class
@WebListener //Annotate this with @WebListener 
public class ContextListener implements ServletContextListener {

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
		System.out.println("Context destroyed...........");
		
	}

	@Override
	public void contextInitialized(ServletContextEvent sContEvent) {
		ServletContext ctx=sContEvent.getServletContext();
		ctx.setInitParameter("Location", "Pune,Hinjewadi");
		
	}
	
}

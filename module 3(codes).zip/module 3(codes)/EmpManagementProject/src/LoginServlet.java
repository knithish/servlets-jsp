

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.UserDto;
import com.cg.service.IUserService;
import com.cg.service.UserserviceImpl;


@WebServlet(name = "LoginServletName", urlPatterns = { "/LoginServletMap" })
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	//Connection conn;
	//PreparedStatement ps;
	//ResultSet rs;
	IUserService userservice;
    public LoginServlet() {
        super();
        System.out.println("Login Servlet constructor");
    }

	public void init(ServletConfig config) throws ServletException {
	/*	try
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","lab011trg17","lab011oracle");
		}
		catch(Exception e)
		{
			
		} */
		System.out.println("LoginServlet is called in init()");
	}

	
	public void destroy() {
		System.out.println("LoginServlet destroy() is called");
	}
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		userservice=new UserserviceImpl();
		PrintWriter out=response.getWriter();
		//Retrieve the data from the form
		String uid=request.getParameter("textUserId");
		String pwd=request.getParameter("textPassword");
		request.setAttribute("UNobj", uid);
		int rowCount=userservice.getUserCount(uid);
		//check whether User Exists or Not?
		if(rowCount!=0)
		{
			UserDto userDto=new UserDto();
			userDto.setUserId(uid);
			userDto.setPassword(pwd);
			if(userservice.isUserValid(userDto))
			{
				//out.println("Welcome:You are valid user");
				RequestDispatcher rdValid=request.getRequestDispatcher("/SuccessServletMap");
				rdValid.forward(request, response);
			}
			else
			{
				//out.println("Sorry Password u have given is wrong");
				RequestDispatcher rdInvalid=request.getRequestDispatcher("HTML/Failure.html");
				rdInvalid.forward(request, response);
			}
		}
		else
		{
			//out.println("Sorry you are not the registered user");
			RequestDispatcher rdReg=request.getRequestDispatcher("HTML/Register.html");
			rdReg.forward(request, response);
		}
		/*out.print("Username: "+uid);
		out.println("Password: "+pwd);
		if((uid.equalsIgnoreCase("Capgemini")) && (pwd.equalsIgnoreCase("capgemini")))
		{
			out.println("Welcome:You are valid user");
		}
		else
		{
			out.println("Sorry You are invalid user");
		} */
	}

}

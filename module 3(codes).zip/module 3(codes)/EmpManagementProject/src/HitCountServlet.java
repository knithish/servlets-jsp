

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "HitCountServletName", urlPatterns = { "/HitCountServletMap" })
public class HitCountServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	int no;
    public HitCountServlet() {
        super();
        System.out.println("HitCountServlet constructor");
    }

	
	public void init(ServletConfig config) throws ServletException {
		System.out.println("In HitCountServlet init() ");
	}

	
	public void destroy() {
		System.out.println("In HitCountServlet destroy()");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		String id=request.getParameter("ID");
		
		if(id==null)
		{
			no=1;
			id="1";
		}
		no=Integer.parseInt(id);
		no++;
		pw.println("Hit count of this servlet is:"+no);
		pw.println("<a href='HitCountServletMap?ID="+no+"'>Go To HitCountSevlet Again</a>");
		
	}

}

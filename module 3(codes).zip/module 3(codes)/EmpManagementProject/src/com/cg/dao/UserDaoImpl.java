package com.cg.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.dto.Employee;
import com.cg.dto.UserDto;
import com.cg.exception.EmployeeException;
import com.cg.util.DBUtil;

public class UserDaoImpl implements IuserDao {
	Connection con;
	PreparedStatement ps;
	ResultSet rs;
	java.sql.Statement st;
	@Override
	public int getUserCount(String uid) {
		con=DBUtil.getConnection();
		String query="SELECT COUNT(*) FROM usertable WHERE userid=?";
 		int count=0;
		try 
		{
			ps=con.prepareStatement(query);
			ps.setString(1, uid);
			rs=ps.executeQuery();
			System.out.println("************ In getUserCount *************");
			rs.next();
			count=rs.getInt(1);
			System.out.println("Count is:"+count);
			/*if(rs.getInt(1)==1)
			{
				count=1;
				System.out.println("Count is:"+count);
			}
			else
			{
				count=0;
				System.out.println("Count is:"+count);
			}*/
		}
		catch (SQLException e) {
			System.out.println(e.getMessage());
		}
		finally
		{
			try
			{
				rs.close();
				ps.close();
				con.close();
			} 
			catch (SQLException e) 
			{
				System.out.println(e.getMessage());
			}
			
		}
		return count;
	}

	@Override
	public boolean isUserValid(UserDto user) {
		con=DBUtil.getConnection();
		String query="SELECT * FROM usertable WHERE userid=?";
		boolean flag=false;
		try 
		{
			ps=con.prepareStatement(query);
			ps.setString(1, user.getUserId());
			rs=ps.executeQuery();
			while(rs.next())
			{
			String un=rs.getString("userid");
			String pw=rs.getString("password");
			if(un.equalsIgnoreCase(user.getUserId()) && pw.equalsIgnoreCase(user.getPassword()))
			{
				flag=true;
			}
			else
			{
				flag=false;
			}
			}
		}
		catch (SQLException e)
		{
			System.out.println(e.getMessage());
		}
		
		return flag;
	}
//**********************Inserting Employees into table******************//
	@Override
	public int insertEmp(Employee empObj) throws EmployeeException {
		con=DBUtil.getConnection();
		String query="INSERT INTO Employee VALUES(?,?,?,(sysdate+3))";
		int dataInserted=0;
		try 
		{
			ps=con.prepareStatement(query);
			ps.setInt(1, empObj.getEmpId());
			ps.setString(2, empObj.getEmpName());
			ps.setInt(3, empObj.getEmpSal());
			dataInserted=ps.executeUpdate();
		} 
		catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		finally
		{
			try
			{
				ps.close();
			}
			catch(Exception e)
			{
				throw new EmployeeException(e.getMessage());
			}
		}
		return dataInserted;
	}

	@Override
	public int getNextEmpId() {
		con=DBUtil.getConnection();
		int nextEmpId=0;
		try 
		{
			st=con.createStatement();
			rs=st.executeQuery("SELECT seq_emp.NEXTVAL FROM DUAL");
			rs.next();
			nextEmpId = rs.getInt(1);
		} 
		catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException(e.getMessage());
		}
		return nextEmpId;
	}

	@Override
	public ArrayList<Employee> getAllEmp() {
		ArrayList<Employee> empList=new ArrayList<Employee>();
		con=DBUtil.getConnection();
		String query="select  * from Employee";
		try
		{
			st=con.createStatement();
			rs=st.executeQuery(query);
			while(rs.next())
			{
				Employee tempEmpObj=new Employee();
				tempEmpObj.setEmpId(rs.getInt("eid"));
				tempEmpObj.setEmpName(rs.getString("ename"));
				tempEmpObj.setEmpSal(rs.getInt("esal"));
				tempEmpObj.setDoj(rs.getDate("doj").toLocalDate());
				empList.add(tempEmpObj);
			}
		}
		catch(Exception e)
		{
			
		}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			
		}
		return empList;
	}

	@Override
	public Employee getEmpByEid(int employeeId) {
		con=DBUtil.getConnection();
		String query="Select * from Employee where eid=?";
		Employee e=new Employee();
		try
		{
			ps=con.prepareStatement(query);
			ps.setInt(1,employeeId);
			rs=ps.executeQuery();
			rs.next();
			
			e.setEmpId(rs.getInt(1));
			e.setEmpName(rs.getString(2));
			e.setEmpSal(rs.getInt(3));
			e.setDoj(rs.getDate("doj").toLocalDate());
		} 
		catch (SQLException ex) 
		{
			ex.printStackTrace();
		}
		finally
		{
			try
			{
				st.close();
				rs.close();
				con.close();
			}
			catch(Exception ex)
			{
				ex.printStackTrace();
			}
		}
		return e;
	}

	@Override
	public int UpdateEmp(Employee emp) {
		con=DBUtil.getConnection();
		String query="UPDATE Employee SET ename=?,esal=?,doj=? WHERE eid=?";
		int dataUpdated=0;
		try 
		{
			ps=con.prepareStatement(query);
			ps.setString(1, emp.getEmpName());
			ps.setInt(2, emp.getEmpSal());
			ps.setInt(3, emp.getEmpId());
			//ps.setDate(4, emp.getDoj());
			dataUpdated=ps.executeUpdate();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return dataUpdated;
	}

	@Override
	public int DeleteEmp(int id) {
		con=DBUtil.getConnection();
		String query="DELETE FROM Employee where eid=?";
		int dataDeleted = 0;
		try 
		{
			ps=con.prepareStatement(query);
			ps.setInt(1, id);
			
			dataDeleted=ps.executeUpdate();
		} 
		catch (SQLException e) {
			e.printStackTrace();
		}
		return dataDeleted;
	}
}

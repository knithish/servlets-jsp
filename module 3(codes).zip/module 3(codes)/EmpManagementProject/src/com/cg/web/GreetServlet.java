package com.cg.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "GreetServletName", urlPatterns = { "/GreetServletMap" })
public class GreetServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    ServletConfig cg;
    public GreetServlet() {
        super();
        System.out.println("In GreetServlet constructor......");
    }


	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		cg=config;
		System.out.println("GreetServlet init() invoked");
	}

	
	public void destroy() {
		System.out.println("GreetServlet destroy() invoked");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		ServletContext ctx=cg.getServletContext();
		String compLocation=ctx.getInitParameter("Location");
		RequestDispatcher rdHeader=ctx.getRequestDispatcher("/HTML/Header.html");
		RequestDispatcher rdFooter=ctx.getRequestDispatcher("/HTML/Footer.html");
		rdHeader.include(request,response);
		pw.write("<b><font color='green'>WELCOME TO SERVLETS </b>");
		pw.write("</font>");
		pw.write("Company Location:"+compLocation);
		rdFooter.include(request,response);
	}

}

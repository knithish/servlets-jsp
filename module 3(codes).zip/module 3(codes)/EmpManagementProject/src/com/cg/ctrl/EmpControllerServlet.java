package com.cg.ctrl;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cg.dto.Employee;
import com.cg.dto.UserDto;
import com.cg.service.IUserService;
import com.cg.service.UserserviceImpl;

@WebServlet("/EmpControllerServlet")
public class EmpControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    ServletConfig cg;  
    IUserService userService=new UserserviceImpl();
    public EmpControllerServlet() {
        super();
       System.out.println("EmpController constructor");
    }

	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		cg=config;
		 System.out.println("EmpController init()");
	}


	public void destroy() {
		 System.out.println("EmpController destroy()");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action=request.getParameter("action");
		PrintWriter out=response.getWriter();
		
		if(action!=null)
		{
			//This action is to display Login Page
			if(action.equals("DisplayLoginPage"))
			{
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/Login.jsp");
				rd.forward(request, response);
			}
			//****************************************
			if(action.equalsIgnoreCase("validateLogin"))
			{
				String uid=request.getParameter("textUserId");
				String pwd=request.getParameter("textPassword");
				
				UserDto user=new UserDto();
				user.setUserId(uid);
				user.setPassword(pwd);
				
				if(userService.getUserCount(uid)!=0)
				{
					if(userService.isUserValid(user))
					{
						HttpSession session=request.getSession(true);
						session.setAttribute("UNObj", user.getUserId());
						//If user id is true it redirect to next action page
						RequestDispatcher rd=request.getRequestDispatcher("/jspPages/EmployeeOperation.jsp");
						rd.forward(request, response);
					}
					else
					{
						//If any mistake happens the it redirect to login page
						RequestDispatcher rd=request.getRequestDispatcher("/jspPages/Login.jsp");
						rd.forward(request, response);
					}
					
				}
				else
				{
					//If it is not valid user,then it goes to registration page to register
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/Register.jsp");
					rd.forward(request, response);
				}
			}
			// *************************************************************************
			//*******************DisplayAddEmpPage******************************
			if(action.equalsIgnoreCase("DisplayAddEmpPage"))
			{
				int nextEmpId=userService.getNextEmpId();
				request.setAttribute("EmpIdObj",nextEmpId);
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/AddEmp.jsp");
				rd.forward(request, response);
			}
			//*******************DisplayListAllEmpPage******************************
			if(action.equalsIgnoreCase("DisplayListAllEmpPage"))
			{
				ArrayList<Employee> eList=userService.getAllEmp();
				request.setAttribute("EmpListObj", eList);
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmp.jsp");
				rd.forward(request, response);
			}
			//*******************INSERT EMP PAGE****************************************
			if(action.equalsIgnoreCase("InsertEmp"))
			{
				//Retrieving the form data
				int empId=Integer.parseInt(request.getParameter("txtEmpId"));
				String ename=request.getParameter("txtEmpName");
				int sal=Integer.parseInt(request.getParameter("txtEmpSal"));
				Employee e=new Employee();
				//Assigning the retrieved data to employee object
				e.setEmpId(empId);
				e.setEmpName(ename);
				e.setEmpSal(sal);
			
				int dataInserted=userService.insertEmp(e);
				
				if(dataInserted==1)
				{
					ArrayList<Employee> eList=userService.getAllEmp();
					request.setAttribute("EmpListObj",eList);
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmp.jsp");
					rd.forward(request, response);
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/EmployeeOperation.jsp");
					request.setAttribute("ErrorMsg", "Some error in data insertion");
					rd.forward(request, response);
				}
			}
			//***********************DISPLAY Update Employee Page******************************
			if(action.equalsIgnoreCase("DisplayUpdateEmpPage"))
			{
				int eid=Integer.parseInt(request.getParameter("eId")); //eId var is from ListAllEmp.jsp page
				Employee tempEmpObj=userService.getEmpByEid(eid);
				request.setAttribute("EmpObj",tempEmpObj);
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/EditEmp.jsp");
				rd.forward(request, response);
				
			}
			//**************************UPDATE EMP DETAILS**************************
			if(action.equalsIgnoreCase("UpdateEmp"))
			{
				
				//Retrieving the form data
				int empId=Integer.parseInt(request.getParameter("txtEmpId"));
				String ename=request.getParameter("txtEmpName");
				int sal=Integer.parseInt(request.getParameter("txtEmpSal"));
				Employee emp=new Employee();
				//Assigning the retrieved data to employee object
				emp.setEmpId(empId);
				emp.setEmpName(ename);
				emp.setEmpSal(sal);

				int dataUpdated=userService.UpdateEmp(emp);
				if(dataUpdated==1)
				{
					ArrayList<Employee> eList=userService.getAllEmp();
					request.setAttribute("EmpListObj", eList);
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmp.jsp");
					rd.forward(request, response);
				}
			}
			//*********************DISPLAY Delete EMP page*******************
			if(action.equalsIgnoreCase("DisplayDeleteEmpPage"))
			{
				ArrayList<Employee> eList=userService.getAllEmp();
				request.setAttribute("EmpListObj", eList);
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmp.jsp");
				rd.forward(request, response);
				
			}
			//***************** DELETE EMP PAGE****************************
			if(action.equalsIgnoreCase("DeleteEmp"))
			{	
				int id=Integer.parseInt(request.getParameter("eId"));
				int dataDeleted=userService.DeleteEmp(id);
				if(dataDeleted==1)
				{
					ArrayList<Employee> eList=userService.getAllEmp();
					request.setAttribute("EmpListObj", eList);
					RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmp.jsp");
					rd.forward(request, response);
				}
				
			}	
			//************************DISPLAY EDIT PAGE****************************
			if(action.equalsIgnoreCase("DisplayEditEmpPage"))
			{
				ArrayList<Employee> eList=userService.getAllEmp();
				request.setAttribute("EmpListObj", eList);
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/ListAllEmp.jsp");
				rd.forward(request, response);
			}
			if(action.equalsIgnoreCase("DisplaySearchEmpPage"))
			{
				RequestDispatcher rd=request.getRequestDispatcher("/jspPages/SearchEmp.jsp");
				rd.forward(request, response);
			}
			if(action.equalsIgnoreCase("SearchEmp"))
			{
				System.out.println("search1");
				int empId=Integer.parseInt(request.getParameter("txtEmpId"));
				Employee emp=new Employee();
				emp=userService.getEmpByEid(empId);
				if(emp.getEmpId()!=0)
				{
					int eid=emp.getEmpId();
					String ename=emp.getEmpName();
					int sal=emp.getEmpSal();
					LocalDate Doj=emp.getDoj();
					
					out.println("Employee Id:"+eid);
					out.println("Employee Name:"+ename);
					
					out.println("Employee Salary:"+sal);
					out.println("Employee DOJ:"+Doj);
				}
			}
				
		}
		else
		{
			out.println("<b>No action Defined</b>");
		}
	}

}

package com.cg.service;

import java.util.ArrayList;

import com.cg.dto.Employee;
import com.cg.dto.UserDto;
import com.cg.exception.EmployeeException;


public interface IUserService {
	public int getUserCount(String uid);
	public boolean isUserValid(UserDto user);
	public int insertEmp(Employee empObj) throws EmployeeException;
	public int getNextEmpId();
	public ArrayList<Employee> getAllEmp();
	public Employee getEmpByEid(int employeeId);
	public int UpdateEmp(Employee emp);
	public int DeleteEmp(int id);
}

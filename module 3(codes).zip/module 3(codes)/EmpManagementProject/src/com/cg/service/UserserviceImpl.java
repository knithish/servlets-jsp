package com.cg.service;

import java.util.ArrayList;

import com.cg.dao.IuserDao;
import com.cg.dao.UserDaoImpl;
import com.cg.dto.Employee;
import com.cg.dto.UserDto;
import com.cg.exception.EmployeeException;


public class UserserviceImpl implements IUserService{
	IuserDao userdao=new UserDaoImpl();
	UserDto user=new UserDto();
	
	@Override
	public int getUserCount(String uid) {
		
		return userdao.getUserCount(uid);
	}

	@Override
	public boolean isUserValid(UserDto user) {
	
		return userdao.isUserValid(user);
	}

	@Override
	public int insertEmp(Employee empObj) throws EmployeeException {
		
		return userdao.insertEmp(empObj);
	}

	@Override
	public int getNextEmpId() {
	
		return userdao.getNextEmpId();
	}

	@Override
	public ArrayList<Employee> getAllEmp() {
		
		return userdao.getAllEmp();
	}

	@Override
	public Employee getEmpByEid(int employeeId) {
		
		return userdao.getEmpByEid(employeeId);
	}

	@Override
	public int UpdateEmp(Employee emp) {
		return userdao.UpdateEmp(emp);
	}

	@Override
	public int DeleteEmp(int id) {
		
		return userdao.DeleteEmp(id);
	}
}
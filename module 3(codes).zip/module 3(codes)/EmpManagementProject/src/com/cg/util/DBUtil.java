package com.cg.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.naming.InitialContext;
import javax.sql.DataSource;


public class DBUtil {
	
			public static Connection getConnection() 
			{
				Connection con=null;
				try
				{
					//String driver="oracle.jdbc.driver.OracleDriver";
					//String url="jdbc:oracle:thin:@ndaoracle.igatecorp.com:1521:orcl11g";
					//String username="lab011trg17";
					//String password="lab011oracle";
					//Class.forName(driver);//load the driver
					//con=DriverManager.getConnection(url, username, password);
					InitialContext mycontext=new InitialContext();
					DataSource datasource= (DataSource)mycontext.lookup("java:/jdbc/sravaniDS");
					con= datasource.getConnection();
				} 
				catch (Exception e) {
					System.out.println(e.getMessage());
				} 
				/* catch (ClassNotFoundException e) {
					System.out.println(e.getMessage());
				} */
				return con;
			}

}




import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ItemListServletName", urlPatterns = { "/ItemListServletMap" })
public class ItemListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	ArrayList<String> itemCartList=null;
    public ItemListServlet() {
        super();
        System.out.println("ItemListServlet constructor");
    }

	
	public void init(ServletConfig config) throws ServletException {
		super.init(config);
		System.out.println("ItemListServlet init()");
	}

	
	public void destroy() {
		
		System.out.println("ItemListServlet destroy()");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession(true);
		
		pw.println("In Item servlet Is session New?"+session.isNew());
		pw.println("<br>In Item servlet session Id is:"+session.getId());
		pw.println("<br>In Item Servlet session creation Time?"+session.getCreationTime());
		pw.println("<br>In Item Servlet session MaxInactiveIntervalTime?"+session.getMaxInactiveInterval());
		
		
		pw.println("<hr color='orange' />");
		
		String bookName=request.getParameter("books"); // books are the name of select tag
		
		itemCartList=(ArrayList) session.getAttribute("CartList");
		if(itemCartList==null)
		{
			itemCartList=new ArrayList<String>();
			itemCartList.add(bookName);
			session.setAttribute("CartList", itemCartList);
		}
		else
		{
			itemCartList.add(bookName);
		}
		pw.println("<br>Books added in cart are:"+itemCartList);
		pw.println("<br><br><a href='CatalogServletMap'>");
		pw.println("Do you want to purchase more books?");
		pw.println("Then Go back again");
		pw.println("</a>");
		
	}

}

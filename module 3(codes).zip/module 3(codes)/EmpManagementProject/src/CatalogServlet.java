

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet(name = "CatalogServletName", urlPatterns = { "/CatalogServletMap" })
public class CatalogServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public CatalogServlet() {
        super();
        System.out.println("In CatalogServlet contsructor");
    }

	public void init(ServletConfig config) throws ServletException {
		System.out.println("CatalogServlet init()");
	}

	
	public void destroy() {
		System.out.println("CatalogServlet destroy()");
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		HttpSession session=request.getSession(true);
		
		pw.println("In catalog servlet Is session New?"+session.isNew());
		pw.println("<br>In catalog servlet session Id is:"+session.getId());
		pw.println("<br>In catalog Servlet session creation Time?"+session.getCreationTime());
		pw.println("<br>In catalog Servlet session MaxInactiveIntervalTime?"+session.getMaxInactiveInterval());
		
		pw.println("<hr color='slateblue'/>");
		
		pw.println("<html><body><h2>Welcome To My BookShop");
		pw.println("<form action='ItemListServletMap'>");
		pw.println("<br>Books Category:<Select name='books' size='1'");
		pw.println("<option>C</option><option>C++</option><option>Java</option>");
		pw.println("<option>DotNet</option><option>HTML</option><option>JavaScript</option>");
		pw.println("<option>OS</option><option>Network</option><option>Compiler</option>");
		pw.println("</select>");
		pw.println("<input type='submit' name='click' value='Add to Cart'>");
		pw.println("</form>");
		pw.println("</body>");
		pw.println("</html>");
	}

}
